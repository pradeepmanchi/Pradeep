package com.batch.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Table_72_hadoop_vw {
@Id
	private String Table_id;

private String  Meterno;
	private String OPCO_CD;
	private String SUBAREA;
	private String COLLECTED_TM;
	private String INSTANTANEOUS_PHASE_A_VOLTAGE;
	private String INSTANTANEOUS_PHASE_B_VOLTAGE;
	private String INSTANTANEOUS_PHASE_C_VOLTAGE;
	private String DISTORTION_PF;
	private String INSTANTANEOUS_CURRENT_PHASE_A;
	private String INSTANTANEOUS_CURRENT_PHASE_B;
	private String INSTANTANEOUS_CURRENT_PHASE_C;
	private String PHA_V_ANG;
	private String PHB_V_ANG;
	private String PHC_V_ANG;
	private String PHA_I_ANG;
	private String PHB_I_ANG;
	private String PHC_I_ANG;
	private String DIAG1_CROSS_PH_COUNTR;
	private String DIAG1_POLARITY_XPHASE;
	private String DIAG2_VOLTG_IMBAL_COUNTR;
	private String DIAG2_VOLTG_IMBAL;
	private String DIAG3_INACT_PH_CURR_COUNTR;
	private String DIAG3_INACT_PH_CURR;
	private String DIAG4_PH_ANG_IMBAL_COUNTR;
	private String DIAG4_PH_ANG_IMBAL;
	private String DIAG6_UNDER_VOLTG_COUNTR;
	private String DIAG6_UNDER_VOLTG;
	private String DIAG7_OVER_VOLTG_COUNTR;
	private String DIAG7_OVER_VOLTG;
	private String DIAG8_HI_NUETRL_COUNTR;
	private String DIAG8_HI_NEUTRL_CURR;
	private String DIAG5A_DISTR_PHA_COUNTR;
	private String DIAG5B_DISTR_PHB_COUNTR;
	private String DIAG5C_DISTR_PHC_COUNTR;
	private String DIAG5_DISTR_ALL_PH_COUNTR;
	private String DIAG5_TOTAL_DISTORTION;
	public synchronized String getTable_id() {
		return Table_id;
	}
	public synchronized void setTable_id(String table_id) {
		Table_id = table_id;
	}
	public synchronized String getOPCO_CD() {
		return OPCO_CD;
	}
	public synchronized void setOPCO_CD(String oPCO_CD) {
		OPCO_CD = oPCO_CD;
	}
	public synchronized String getSUBAREA() {
		return SUBAREA;
	}
	public synchronized void setSUBAREA(String sUBAREA) {
		SUBAREA = sUBAREA;
	}
	public synchronized String getCOLLECTED_TM() {
		return COLLECTED_TM;
	}
	public synchronized void setCOLLECTED_TM(String cOLLECTED_TM) {
		COLLECTED_TM = cOLLECTED_TM;
	}
	public synchronized String getINSTANTANEOUS_PHASE_A_VOLTAGE() {
		return INSTANTANEOUS_PHASE_A_VOLTAGE;
	}
	public synchronized void setINSTANTANEOUS_PHASE_A_VOLTAGE(String iNSTANTANEOUS_PHASE_A_VOLTAGE) {
		INSTANTANEOUS_PHASE_A_VOLTAGE = iNSTANTANEOUS_PHASE_A_VOLTAGE;
	}
	public synchronized String getINSTANTANEOUS_PHASE_B_VOLTAGE() {
		return INSTANTANEOUS_PHASE_B_VOLTAGE;
	}
	public synchronized void setINSTANTANEOUS_PHASE_B_VOLTAGE(String iNSTANTANEOUS_PHASE_B_VOLTAGE) {
		INSTANTANEOUS_PHASE_B_VOLTAGE = iNSTANTANEOUS_PHASE_B_VOLTAGE;
	}
	public synchronized String getINSTANTANEOUS_PHASE_C_VOLTAGE() {
		return INSTANTANEOUS_PHASE_C_VOLTAGE;
	}
	public synchronized void setINSTANTANEOUS_PHASE_C_VOLTAGE(String iNSTANTANEOUS_PHASE_C_VOLTAGE) {
		INSTANTANEOUS_PHASE_C_VOLTAGE = iNSTANTANEOUS_PHASE_C_VOLTAGE;
	}
	public synchronized String getDISTORTION_PF() {
		return DISTORTION_PF;
	}
	public synchronized void setDISTORTION_PF(String dISTORTION_PF) {
		DISTORTION_PF = dISTORTION_PF;
	}
	public synchronized String getINSTANTANEOUS_CURRENT_PHASE_A() {
		return INSTANTANEOUS_CURRENT_PHASE_A;
	}
	public synchronized void setINSTANTANEOUS_CURRENT_PHASE_A(String iNSTANTANEOUS_CURRENT_PHASE_A) {
		INSTANTANEOUS_CURRENT_PHASE_A = iNSTANTANEOUS_CURRENT_PHASE_A;
	}
	public synchronized String getINSTANTANEOUS_CURRENT_PHASE_B() {
		return INSTANTANEOUS_CURRENT_PHASE_B;
	}
	public synchronized void setINSTANTANEOUS_CURRENT_PHASE_B(String iNSTANTANEOUS_CURRENT_PHASE_B) {
		INSTANTANEOUS_CURRENT_PHASE_B = iNSTANTANEOUS_CURRENT_PHASE_B;
	}
	public synchronized String getINSTANTANEOUS_CURRENT_PHASE_C() {
		return INSTANTANEOUS_CURRENT_PHASE_C;
	}
	public synchronized void setINSTANTANEOUS_CURRENT_PHASE_C(String iNSTANTANEOUS_CURRENT_PHASE_C) {
		INSTANTANEOUS_CURRENT_PHASE_C = iNSTANTANEOUS_CURRENT_PHASE_C;
	}
	public synchronized String getPHA_V_ANG() {
		return PHA_V_ANG;
	}
	public synchronized void setPHA_V_ANG(String pHA_V_ANG) {
		PHA_V_ANG = pHA_V_ANG;
	}
	public synchronized String getPHB_V_ANG() {
		return PHB_V_ANG;
	}
	public synchronized void setPHB_V_ANG(String pHB_V_ANG) {
		PHB_V_ANG = pHB_V_ANG;
	}
	public synchronized String getPHC_V_ANG() {
		return PHC_V_ANG;
	}
	public synchronized void setPHC_V_ANG(String pHC_V_ANG) {
		PHC_V_ANG = pHC_V_ANG;
	}
	public synchronized String getPHA_I_ANG() {
		return PHA_I_ANG;
	}
	public synchronized void setPHA_I_ANG(String pHA_I_ANG) {
		PHA_I_ANG = pHA_I_ANG;
	}
	public synchronized String getPHB_I_ANG() {
		return PHB_I_ANG;
	}
	public synchronized void setPHB_I_ANG(String pHB_I_ANG) {
		PHB_I_ANG = pHB_I_ANG;
	}
	public synchronized String getPHC_I_ANG() {
		return PHC_I_ANG;
	}
	public synchronized void setPHC_I_ANG(String pHC_I_ANG) {
		PHC_I_ANG = pHC_I_ANG;
	}
	public synchronized String getDIAG1_CROSS_PH_COUNTR() {
		return DIAG1_CROSS_PH_COUNTR;
	}
	public synchronized void setDIAG1_CROSS_PH_COUNTR(String dIAG1_CROSS_PH_COUNTR) {
		DIAG1_CROSS_PH_COUNTR = dIAG1_CROSS_PH_COUNTR;
	}
	public synchronized String getDIAG1_POLARITY_XPHASE() {
		return DIAG1_POLARITY_XPHASE;
	}
	public synchronized void setDIAG1_POLARITY_XPHASE(String dIAG1_POLARITY_XPHASE) {
		DIAG1_POLARITY_XPHASE = dIAG1_POLARITY_XPHASE;
	}
	public synchronized String getDIAG2_VOLTG_IMBAL_COUNTR() {
		return DIAG2_VOLTG_IMBAL_COUNTR;
	}
	public synchronized void setDIAG2_VOLTG_IMBAL_COUNTR(String dIAG2_VOLTG_IMBAL_COUNTR) {
		DIAG2_VOLTG_IMBAL_COUNTR = dIAG2_VOLTG_IMBAL_COUNTR;
	}
	public synchronized String getDIAG2_VOLTG_IMBAL() {
		return DIAG2_VOLTG_IMBAL;
	}
	public synchronized void setDIAG2_VOLTG_IMBAL(String dIAG2_VOLTG_IMBAL) {
		DIAG2_VOLTG_IMBAL = dIAG2_VOLTG_IMBAL;
	}
	public synchronized String getDIAG3_INACT_PH_CURR_COUNTR() {
		return DIAG3_INACT_PH_CURR_COUNTR;
	}
	public synchronized void setDIAG3_INACT_PH_CURR_COUNTR(String dIAG3_INACT_PH_CURR_COUNTR) {
		DIAG3_INACT_PH_CURR_COUNTR = dIAG3_INACT_PH_CURR_COUNTR;
	}
	public synchronized String getDIAG3_INACT_PH_CURR() {
		return DIAG3_INACT_PH_CURR;
	}
	public synchronized void setDIAG3_INACT_PH_CURR(String dIAG3_INACT_PH_CURR) {
		DIAG3_INACT_PH_CURR = dIAG3_INACT_PH_CURR;
	}
	public synchronized String getDIAG4_PH_ANG_IMBAL_COUNTR() {
		return DIAG4_PH_ANG_IMBAL_COUNTR;
	}
	public synchronized void setDIAG4_PH_ANG_IMBAL_COUNTR(String dIAG4_PH_ANG_IMBAL_COUNTR) {
		DIAG4_PH_ANG_IMBAL_COUNTR = dIAG4_PH_ANG_IMBAL_COUNTR;
	}
	public synchronized String getDIAG4_PH_ANG_IMBAL() {
		return DIAG4_PH_ANG_IMBAL;
	}
	public synchronized void setDIAG4_PH_ANG_IMBAL(String dIAG4_PH_ANG_IMBAL) {
		DIAG4_PH_ANG_IMBAL = dIAG4_PH_ANG_IMBAL;
	}
	public synchronized String getDIAG6_UNDER_VOLTG_COUNTR() {
		return DIAG6_UNDER_VOLTG_COUNTR;
	}
	public synchronized void setDIAG6_UNDER_VOLTG_COUNTR(String dIAG6_UNDER_VOLTG_COUNTR) {
		DIAG6_UNDER_VOLTG_COUNTR = dIAG6_UNDER_VOLTG_COUNTR;
	}
	public synchronized String getDIAG6_UNDER_VOLTG() {
		return DIAG6_UNDER_VOLTG;
	}
	public synchronized void setDIAG6_UNDER_VOLTG(String dIAG6_UNDER_VOLTG) {
		DIAG6_UNDER_VOLTG = dIAG6_UNDER_VOLTG;
	}
	public synchronized String getDIAG7_OVER_VOLTG_COUNTR() {
		return DIAG7_OVER_VOLTG_COUNTR;
	}
	public synchronized void setDIAG7_OVER_VOLTG_COUNTR(String dIAG7_OVER_VOLTG_COUNTR) {
		DIAG7_OVER_VOLTG_COUNTR = dIAG7_OVER_VOLTG_COUNTR;
	}
	public synchronized String getDIAG7_OVER_VOLTG() {
		return DIAG7_OVER_VOLTG;
	}
	public synchronized void setDIAG7_OVER_VOLTG(String dIAG7_OVER_VOLTG) {
		DIAG7_OVER_VOLTG = dIAG7_OVER_VOLTG;
	}
	public synchronized String getDIAG8_HI_NUETRL_COUNTR() {
		return DIAG8_HI_NUETRL_COUNTR;
	}
	public synchronized void setDIAG8_HI_NUETRL_COUNTR(String dIAG8_HI_NUETRL_COUNTR) {
		DIAG8_HI_NUETRL_COUNTR = dIAG8_HI_NUETRL_COUNTR;
	}
	public synchronized String getDIAG8_HI_NEUTRL_CURR() {
		return DIAG8_HI_NEUTRL_CURR;
	}
	public synchronized void setDIAG8_HI_NEUTRL_CURR(String dIAG8_HI_NEUTRL_CURR) {
		DIAG8_HI_NEUTRL_CURR = dIAG8_HI_NEUTRL_CURR;
	}
	public synchronized String getDIAG5A_DISTR_PHA_COUNTR() {
		return DIAG5A_DISTR_PHA_COUNTR;
	}
	public synchronized void setDIAG5A_DISTR_PHA_COUNTR(String dIAG5A_DISTR_PHA_COUNTR) {
		DIAG5A_DISTR_PHA_COUNTR = dIAG5A_DISTR_PHA_COUNTR;
	}
	public synchronized String getDIAG5B_DISTR_PHB_COUNTR() {
		return DIAG5B_DISTR_PHB_COUNTR;
	}
	public synchronized void setDIAG5B_DISTR_PHB_COUNTR(String dIAG5B_DISTR_PHB_COUNTR) {
		DIAG5B_DISTR_PHB_COUNTR = dIAG5B_DISTR_PHB_COUNTR;
	}
	public synchronized String getDIAG5C_DISTR_PHC_COUNTR() {
		return DIAG5C_DISTR_PHC_COUNTR;
	}
	public synchronized void setDIAG5C_DISTR_PHC_COUNTR(String dIAG5C_DISTR_PHC_COUNTR) {
		DIAG5C_DISTR_PHC_COUNTR = dIAG5C_DISTR_PHC_COUNTR;
	}
	public synchronized String getDIAG5_DISTR_ALL_PH_COUNTR() {
		return DIAG5_DISTR_ALL_PH_COUNTR;
	}
	public synchronized void setDIAG5_DISTR_ALL_PH_COUNTR(String dIAG5_DISTR_ALL_PH_COUNTR) {
		DIAG5_DISTR_ALL_PH_COUNTR = dIAG5_DISTR_ALL_PH_COUNTR;
	}
	public synchronized String getDIAG5_TOTAL_DISTORTION() {
		return DIAG5_TOTAL_DISTORTION;
	}
	public synchronized void setDIAG5_TOTAL_DISTORTION(String dIAG5_TOTAL_DISTORTION) {
		DIAG5_TOTAL_DISTORTION = dIAG5_TOTAL_DISTORTION;
	}
	
	
}
