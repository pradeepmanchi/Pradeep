package com.batch.model;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class KafkaObj {
	/*
	Properties prop = null;
	
	  KafkaProducer<String,String> table72Producer= null;

	@PostConstruct
	public void setProperties() {
	  System.setProperty("java.security.auth.login.config", "C://Users//s284071//Desktop//kafka//config//kafka_client_jaas.conf");
      String bootstrapServers="b-3.aep-datalake-msk-dev.xfwv49.c20.kafka.us-east-1.amazonaws.com:9096,b-2.aep-datalake-msk-dev.xfwv49.c20.kafka.us-east-1.amazonaws.com:9096,b-1.aep-datalake-msk-dev.xfwv49.c20.kafka.us-east-1.amazonaws.com:9096";
       prop = new Properties();
      prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
      prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
      prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
      prop.put("security.protocol", "SASL_SSL");
      prop.put("sasl.mechanism", "SCRAM-SHA-512");
      prop.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,"/tmp/cacerts");
      prop.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,"changeit");
    	
      prop.put("linger.ms",1000);
      prop.put("batch.size", 20000);
      prop.put("buffer.memory", 33554432);
      table72Producer = new KafkaProducer<String, String>(prop);
	
	}
	
	*/
}
