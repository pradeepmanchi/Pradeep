package com.batch.items;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class Reader extends JdbcCursorItemReader<String> implements 

ItemReader<String>{
	
	public Reader(@Autowired DataSource primaryDataSource) {
		setDataSource(primaryDataSource);
		setSql("SELECT * FROM TABLE_72_HADOOP_VW");
		setRowMapper(new Table72Mapper());
		System.out.println("R"+Thread.currentThread().getName());
	}


	public class Table72Mapper implements RowMapper<String> {
		public static final String STRING = ",";

		@Override
		public String mapRow(ResultSet myResultSet, int rowNum) throws SQLException {
			 String Tbl72data = myResultSet.getString("Meterno")+STRING+myResultSet.getString("Table_id")+STRING+ myResultSet.getString("OPCO_CD")
             +STRING+ myResultSet.getString("SUBAREA")
             +STRING+ myResultSet.getString("COLLECTED_TM")
             +STRING+ myResultSet.getString("INSTANTANEOUS_PHASE_A_VOLTAGE")
             +STRING+ myResultSet.getString("INSTANTANEOUS_PHASE_B_VOLTAGE")
             +STRING+ myResultSet.getString("INSTANTANEOUS_PHASE_C_VOLTAGE")
             +STRING+ myResultSet.getString("DISTORTION_PF")
             +STRING+ myResultSet.getString("INSTANTANEOUS_CURRENT_PHASE_A")
             +STRING+ myResultSet.getString("INSTANTANEOUS_CURRENT_PHASE_B")
             +STRING+ myResultSet.getString("INSTANTANEOUS_CURRENT_PHASE_C")
             +STRING+ myResultSet.getString("PHA_V_ANG")
             +STRING+ myResultSet.getString("PHB_V_ANG")
             +STRING+ myResultSet.getString("PHC_V_ANG")
             +STRING+ myResultSet.getString("PHA_I_ANG")
             +STRING+ myResultSet.getString("PHB_I_ANG")
             +STRING+ myResultSet.getString("PHC_I_ANG")
             +STRING+ myResultSet.getString("DIAG1_CROSS_PH_COUNTR")
             +STRING+ myResultSet.getString("DIAG1_POLARITY_XPHASE")
             +STRING+ myResultSet.getString("DIAG2_VOLTG_IMBAL_COUNTR")
             +STRING+ myResultSet.getString("DIAG2_VOLTG_IMBAL")
             +STRING+ myResultSet.getString("DIAG3_INACT_PH_CURR_COUNTR")
             +STRING+ myResultSet.getString("DIAG3_INACT_PH_CURR")
             +STRING+ myResultSet.getString("DIAG4_PH_ANG_IMBAL_COUNTR")
             +STRING+ myResultSet.getString("DIAG4_PH_ANG_IMBAL")
             +STRING+ myResultSet.getString("DIAG6_UNDER_VOLTG_COUNTR")
             +STRING+ myResultSet.getString("DIAG6_UNDER_VOLTG")
             +STRING+ myResultSet.getString("DIAG7_OVER_VOLTG_COUNTR")
             +STRING+ myResultSet.getString("DIAG7_OVER_VOLTG")
             +STRING+ myResultSet.getString("DIAG8_HI_NUETRL_COUNTR")
             +STRING+ myResultSet.getString("DIAG8_HI_NEUTRL_CURR")
             +STRING+ myResultSet.getString("DIAG5A_DISTR_PHA_COUNTR")
             +STRING+ myResultSet.getString("DIAG5B_DISTR_PHB_COUNTR")
             +STRING+ myResultSet.getString("DIAG5C_DISTR_PHC_COUNTR")
             +STRING+ myResultSet.getString("DIAG5_DISTR_ALL_PH_COUNTR")
             +STRING+ myResultSet.getString("DIAG5_TOTAL_DISTORTION");
			return Tbl72data;
		}
	}
	
	
}
