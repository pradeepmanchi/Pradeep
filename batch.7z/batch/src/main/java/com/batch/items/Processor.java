package com.batch.items;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;


@Component
public class Processor  implements ItemProcessor<String, String> {

  

 

    @Override
    public String process(String user) throws Exception {
    	System.out.println("P"+Thread.currentThread().getName()+user);
    	
    	
	
        return user;
    }
}
