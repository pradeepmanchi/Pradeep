package com.batch.items;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.model.KafkaObj;

@Component
public class Writer implements ItemWriter<String> {

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSS");
	@Autowired
	private KafkaObj kafkaObj;

	@Override
	public void write(List<? extends String> items) throws Exception {
//	ProducerRecord<String, String> record;

		System.out.println("W" + Thread.currentThread().getName() + items.size());

		try {
			for (String message : items) {

				String formattedDate = sdf.format(new Date());

				// record = new ProducerRecord<>("LG-INSTANTANEOUS-MT72-CSV-TX"+formattedDate,
				// message);
				// kafkaObj.table72Producer.send();
				// kafkaObj.table72Producer.flush();
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			// kafkaObj.table72Producer.close();
		}

	}

}
