package com.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableBatchProcessing
@EnableScheduling
public class BatchApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(BatchApplication.class, args);
	}
	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
			ItemReader<String> itemReader, ItemProcessor<String, String> itemProcessor, ItemWriter<String> itemWriter) {

		Step step = stepBuilderFactory.get("Publish TABLE_72_HADOOP DATA").<String, String>chunk(100).reader( itemReader)
				.processor(itemProcessor).writer(itemWriter).build();

		return jobBuilderFactory.get("publish_job").incrementer(new RunIdIncrementer())
				
				
				.listener(listener())
				.flow(step).end().build();
	}
	
	
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}

	
}
